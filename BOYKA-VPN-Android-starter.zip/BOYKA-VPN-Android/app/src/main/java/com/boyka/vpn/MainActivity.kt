package com.boyka.vpn

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView

class MainActivity : Activity() {
    private val navy = Color.rgb(7, 20, 38)
    private val blue = Color.rgb(35, 166, 235)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 52, 32, 32)
            setBackgroundColor(navy)
        }

        val logo = TextView(this).apply {
            text = "BOYKA VPN"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        page.addView(logo)

        val subtitle = TextView(this).apply {
            text = "GAMING EDITION  •  WIREGUARD"
            textSize = 13f
            setTextColor(blue)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 36)
        }
        page.addView(subtitle)

        val state = TextView(this).apply {
            text = "غير متصل"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 24)
        }
        page.addView(state)

        val serverLabel = TextView(this).apply {
            text = "اختار المنطقة (اختيار تجريبي حالياً)"
            textSize = 14f
            setTextColor(Color.LTGRAY)
        }
        page.addView(serverLabel)

        val servers = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("المغرب", "فرنسا", "ألمانيا", "هولندا")
            )
        }
        page.addView(servers)

        val connect = Button(this).apply {
            text = "اتصال"
            isEnabled = false
            alpha = 0.65f
        }
        page.addView(connect)

        val info = TextView(this).apply {
            text = "النسخة 0.1: هيكل التطبيق فقط. الاتصال غير مفعّل حتى نضيف إعداد WireGuard صحيحاً وخادماً حقيقياً. اختيار الدولة لا يعني وجود سيرفر فيها."
            textSize = 13f
            setTextColor(Color.rgb(170, 194, 215))
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }
        page.addView(info)

        setContentView(page)
    }
}
